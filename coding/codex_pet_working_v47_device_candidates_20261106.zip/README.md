# Codex Pet WORKING V47 — Deliverable art and constrained 2D hair rig

**STATUS: REVIEW / READY FOR CODEX TRIAL**. Not physically burn-in tested.

Based on V45 accepted Pose4 art exactly, inheriting V46 extracted hair source partitions. 466x466 alpha sprite and seven hair layers are unchanged in visible RGB/RGBA. V47 adds a reproducible 24s composed motion: seven separate 3-joint hair controls, one 3-joint tail, stationary face/eyes/hat/boots/hands/tablet glass, and tablet content motion.

## What is real vs. planned
- **Real:** 19 visible editable ORA layers, seven distinct hair influence masks, 21 hair control nodes, source-derived pixel-safe 2D skinning, full 24s WebP/GIF and offline HTML. Every RGBA original visible pixel reconstructs at neutral, protected areas and hair-core alpha tested across 96 times.
- **Not real:** missing hair behind other hair/neck or a full-turn head sprite. `occlusion_underpaint_reference.png` is merely a safe inner-hair backup texture, *not* painted missing anatomy. Do not freely rotate hair layers by large angles. The source-differentiated hair groups are editable but production renderer uses one coherent inverse-UV composite to suppress seams.
- No guarantee of native LVGL descriptors, ESP32 RAM/FPS or hardware compatibility. Codex integrates and benchmarks.

## Files
- `assets/source/character_v45_unchanged.png`: pixel-exact accepted V45 source.
- `source/working_v47_editable.ora`: 19 visible layers + hidden guides; source neutral reconstruction.
- `assets/hair/`: 7 source hair layers, cropped sprites and inner-hair backup guide.
- `assets/masks/`: 7 per-group influence maps, protected region and tail map.
- `source/rig_v47.json`, `source/motion_samples_8fps.csv`: authored parameters and sample angles.
- `source/build_v47.py`: reproducible preview renderer. Run with V46 input materialized in the sibling source dir; config path at file top.
- `preview/working_v47_24s.webp`, `.gif`, `mobile_preview.html`.
- `qa/QA_REPORT.json`.

## State contract
Only persistent scenes are IDLE and WORKING. `thinking`/`coding`/`working` are aliases, preserve animation phase during alias changes. IDLE <-> WORKING uses a scene cut, not a turn animation.

All file and ZIP paths are ASCII only. No writes to other library modules.
