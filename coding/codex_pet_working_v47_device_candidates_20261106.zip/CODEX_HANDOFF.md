# WORKING V47 Codex art handoff

## Handoff scope and acceptance
- Art module only. All assets source-derived from V45 approved front-holding-terminal image, V46 hair-only strata.
- WORKING visual scene represents `thinking`, `coding`, `working`. Do not restart motion when aliases change. Idle->Working and Working->Idle are scene cuts.
- Default: 24s periodic timeline. Terminal contents synthetic. Integrated state/busy signals belong to Codex, never inferred from decorative lines.

## Runtime options (Codex selects after benchmarking)
1. **Mesh runtime**: implement 7 separate root/mid/tip weight maps + 1 tail map with 2D inverse UV mapping, use `source/rig_v47.json` and Python renderer as mathematical reference. Head microtilt must move face/eyes/beret coherently. The seven PNG source layers alone are *not* independently rotation safe.
2. **Pre-rendered sprites**: generate time samples with `source/build_v47.py`; use cropped RGB565/A8 or compressed image frames and measure flash/PSRAM/FPS on the device. `preview/*.webp` is for browser art review, not an ESP32 native animation decoder. Avoid full-frame delta stream by default unless measured budget allows it.
3. `device_candidates/` contains static 466px render samples and compact hair source crops for resource inspection, NOT LVGL image descriptors.

## Layering / occlusion
- The `working_v47_editable.ora` has 19 source-derived visible layers and 3 hidden guide layers. Neutral RGBA reconstruction is byte-for-byte identical to V45.
- `assets/hair/occlusion_underpaint_reference.png` is an *inner-hair silhouette safety guide* only; not recovered hidden neck or new hair anatomy. Keep rotations/mesh displacement inside `rig_v47.json` safety limits until actual occluded regions are hand-painted.
- For this reason the demonstration uses a single coherently remapped RGBA texture driven by independently weighted hair bone chains, not 7 independently rigid rotated PNGs. Independent source layers remain editable.

## Device acceptance to request
- Use native 466x466 AMOLED circular viewport; inspect boundary clipping and antialiasing.
- Confirm hair does not expose alpha cracks at full brightness; confirm eyes, scarf/mic, tablet and shoes do not shear.
- Log real PSRAM peak, image/texture cache, frame duration P95, display flush regions and full 24h visual stability.
- Check working alias handoff preserves animation phase and Idle swap uses instant cut.

## Known art limits
- No full painted hidden anatomy for side-view head rotation. No large hair rotations.
- No independent V45 closed-eye assets. Eyes follow head in microtilt but the blink artwork was not resourced in this hair-only release.
- No hardware flash completed in this package.
